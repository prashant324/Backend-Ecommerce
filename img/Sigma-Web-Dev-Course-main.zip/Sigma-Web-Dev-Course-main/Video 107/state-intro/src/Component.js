import React from 'react'

const Component = () => {
  return (
    <div>
      <div className="container flex">
    <div className="item">Harry</div>
    <div className="item">Rohan</div>
    <div className="item">Izhan</div>
    <div className="item">Harshita</div>
      </div>
      <div className="itemcontainer">
         <div className="item this">
            j
         </div>
      </div>
    </div>
  )
}

export default Component
