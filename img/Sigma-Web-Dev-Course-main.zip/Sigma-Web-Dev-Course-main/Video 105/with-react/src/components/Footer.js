import React from 'react'

const Footer = () => {
  return (
    <div>
      I am a footer2
      
    </div>
  )
}

export default Footer
