Types of Hosting:
1. Shared Hosting
2. Dedicated Hosting
3. Managed Hosting

Linux Tutorial: https://www.youtube.com/watch?v=_tCY-c-sPZc