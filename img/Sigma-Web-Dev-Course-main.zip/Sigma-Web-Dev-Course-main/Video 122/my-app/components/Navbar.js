"use client"
import React from 'react'

const Navbar = () => {
  return (
    <div>
      navbar
    </div>
  )
}

export default Navbar
