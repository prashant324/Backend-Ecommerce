import React from 'react'

const about = () => {
  return (
    <div>
      About
    </div>
  )
}

export default about

export const metadata = {
    title: "About Facebook - Connect with the world",
    description: "This is about facebook and we can connect with the world using facebook",
  };