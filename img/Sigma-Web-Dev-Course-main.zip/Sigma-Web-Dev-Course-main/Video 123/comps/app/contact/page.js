import React from 'react'

const Contact = () => {
  return (
    <div>
      I am contact
    </div>
  )
}

export default Contact
