'use client'
 

export default function Home() {
  

  return (
    <>
    <div className="hidden  translate-x-[0%] translate-x-[100%] translate-x-[200%]"></div>

      <div className="slider bg-red-500 overflow-hidden flex ">
        <img className="" src="http://www.menucool.com/slider/prod/image-slider-1.jpg" alt="" />
        <img className="" src="http://www.menucool.com/slider/prod/image-slider-2.jpg" alt="" />
        <img className="" src="http://www.menucool.com/slider/prod/image-slider-3.jpg" alt="" />

      </div>
    </>
  );
}
