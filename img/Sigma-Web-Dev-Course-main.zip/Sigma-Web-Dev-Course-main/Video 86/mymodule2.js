// module.exports = {
//     a: 1,
//     b:4
// }

let c = 56;
module.exports = c;