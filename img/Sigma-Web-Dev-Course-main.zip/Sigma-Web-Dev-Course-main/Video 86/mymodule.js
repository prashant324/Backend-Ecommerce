export const a = 1 // named export
export const b = 2 // named export
export const c = 3 // named export
export const d = 4 // named export
export const e = 5 // named export
 
const obj = {
    x: 5,
    y: 7
}

export default obj; // default export