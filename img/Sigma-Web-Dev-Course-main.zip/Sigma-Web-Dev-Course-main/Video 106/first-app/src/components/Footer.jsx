import React from 'react'
import "./Footer.css"
const Footer = () => {
  return (
    <div className='footer'>
      Copyright &copy; www.codewithharry.com | All rights reserved
    </div>
  )
}

export default Footer
