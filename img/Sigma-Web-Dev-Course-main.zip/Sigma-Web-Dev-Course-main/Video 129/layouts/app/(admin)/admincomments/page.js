import React from 'react'

const Comment = () => {
  return (
    <div>
      Comments
    </div>
  )
}

export default Comment
