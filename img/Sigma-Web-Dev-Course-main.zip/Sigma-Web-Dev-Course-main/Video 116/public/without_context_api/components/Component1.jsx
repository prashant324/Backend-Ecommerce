import React from 'react'

const Component1 = ({count}) => {
  return (
    <div>
     {count}
    </div>
  )
}

export default Component1
