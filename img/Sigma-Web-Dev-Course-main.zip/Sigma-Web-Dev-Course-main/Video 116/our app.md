App.jsx
    Navbar.jsx  
        Button.jsx
            Component1.jsx