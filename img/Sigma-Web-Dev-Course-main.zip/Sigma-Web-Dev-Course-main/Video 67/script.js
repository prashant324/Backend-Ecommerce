console.log("Hello world")

document.body.firstElementChild 
document.body.firstElementChild.childNodes 
document.body.firstElementChild.children