console.log("Hello World")
console.log("Code is running...")
console.log("Code is also running...")
console.log("Code is looking like a wow...")