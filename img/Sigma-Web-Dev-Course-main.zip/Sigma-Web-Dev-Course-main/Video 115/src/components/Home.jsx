import React from 'react'

const Home = () => {
  return (
    <div>
      I am Home
    </div>
  )
}

export default Home
