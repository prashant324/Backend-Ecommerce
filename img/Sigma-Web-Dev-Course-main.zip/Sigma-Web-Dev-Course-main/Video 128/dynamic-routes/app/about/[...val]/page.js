export default function Page({ params }) {
    console.log(params)
    // fetch your blog post by its slug
    return <div>I am about page check console</div>
  }