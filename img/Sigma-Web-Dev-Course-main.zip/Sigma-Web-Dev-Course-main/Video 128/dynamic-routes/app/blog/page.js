import React from 'react'

const page = () => {
  return (
    <div>
      All Blogs
    </div>
  )
}

export default page
