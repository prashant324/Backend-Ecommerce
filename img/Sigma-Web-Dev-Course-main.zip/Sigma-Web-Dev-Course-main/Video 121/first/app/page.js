import React from 'react'

const page = () => {
  return (
    <div>
      <div>I am homepage</div>
    </div>
  )
}

export default page
