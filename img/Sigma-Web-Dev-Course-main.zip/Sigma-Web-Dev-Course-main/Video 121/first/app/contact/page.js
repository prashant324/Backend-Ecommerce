import React from 'react'

const contact = () => {
  return (
    <div>
      I am contact
    </div>
  )
}

export default contact
