import React from 'react'

const Navbar = () => {
  return (
    <div>
      I am navbar
    </div>
  )
}

export default Navbar
